document.addEventListener('DOMContentLoaded', function () {
  var myFrame = document.getElementById('explore');
  myFrame.src = "http://info.maestro.io/twitch?twitch-pop=1";
});

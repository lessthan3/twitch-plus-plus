v1.0.0
  - embed custom maestro channels on twitch.tv

v1.0.1
 - removed VOD support
 - db drive list of channels
 - updated icons

v1.0.2
 - fixing crash from missing icon

v1.0.3
 - special icon for browser action

 v1.1.0
 - Directory View for channels
 - Fix for margin-right being forced

v1.1.1
 - Updating 128 icon

v1.1.2
 - adding readme description
